

function cropdone(){
    return "click on crop";
};

function basic()
{
    return "basic";
};

function inputimage()
{
    return "image imported";
};

function editoropened()
{
    return "editor opened";

};

function drawn()
{
    return "drawn successfully";
};

function filtersapplied()
{
    return "filters applied";
};

function layersstored()
{
    return "Layers stored";
};

function historyControl()
{
    return "history under control";
};

function saveimage()
{
    return "image saved successfully";
};